package com.smartqueue.queue.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;
@Entity
public class QueueToken {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long userId;
    private Long queueId;
    private Long counterId;

    private Integer position;

    private String status; // WAITING, COMPLETED, CANCELLED

    private String priorityType; // EMERGENCY, PREMIUM, NORMAL

    private LocalDateTime createdAt;

    @PrePersist
    public void prePersist() {
        this.createdAt = LocalDateTime.now();
    }
    public QueueToken() {
		// TODO Auto-generated constructor stub
	}

	public QueueToken(Long id, Long userId, Long queueId, Long counterId, Integer position, String status,
			String priorityType, LocalDateTime createdAt) {
		super();
		this.id = id;
		this.userId = userId;
		this.queueId = queueId;
		this.counterId = counterId;
		this.position = position;
		this.status = status;
		this.priorityType = priorityType;
		this.createdAt = createdAt;
	}
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public Long getQueueId() {
		return queueId;
	}

	public void setQueueId(Long queueId) {
		this.queueId = queueId;
	}

	public Long getCounterId() {
		return counterId;
	}

	public void setCounterId(Long counterId) {
		this.counterId = counterId;
	}

	public Integer getPosition() {
		return position;
	}

	public void setPosition(Integer position) {
		this.position = position;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getPriorityType() {
		return priorityType;
	}

	public void setPriorityType(String priorityType) {
		this.priorityType = priorityType;
	}

	public LocalDateTime getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}

    // getters/setters
    
}