package com.smartqueue.queue.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
public class StandbyUser {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long userId;
    private Long queueId;

    private Integer position;

    private LocalDateTime joinedAt;

    @PrePersist
    public void prePersist() {
        this.joinedAt = LocalDateTime.now();
    }
public StandbyUser() {
	// TODO Auto-generated constructor stub
}
public StandbyUser(Long id, Long userId, Long queueId, Integer position, LocalDateTime joinedAt) {
	super();
	this.id = id;
	this.userId = userId;
	this.queueId = queueId;
	this.position = position;
	this.joinedAt = joinedAt;
}
public Long getId() {
	return id;
}
public void setId(Long id) {
	this.id = id;
}
public Long getUserId() {
	return userId;
}
public void setUserId(Long userId) {
	this.userId = userId;
}
public Long getQueueId() {
	return queueId;
}
public void setQueueId(Long queueId) {
	this.queueId = queueId;
}
public Integer getPosition() {
	return position;
}
public void setPosition(Integer position) {
	this.position = position;
}
public LocalDateTime getJoinedAt() {
	return joinedAt;
}
public void setJoinedAt(LocalDateTime joinedAt) {
	this.joinedAt = joinedAt;
}

    // getters/setters
}