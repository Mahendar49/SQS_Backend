package com.smartqueue.queue.entity;

import java.time.LocalDateTime;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;

@Entity
public class Cancellation {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long tokenId;
    private LocalDateTime cancelTime;
    private String reason;

    @PrePersist
    public void prePersist() {
        this.cancelTime = LocalDateTime.now();
    }
    public Cancellation() {
		// TODO Auto-generated constructor stub
	}
	public Cancellation(Long id, Long tokenId, LocalDateTime cancelTime, String reason) {
		super();
		this.id = id;
		this.tokenId = tokenId;
		this.cancelTime = cancelTime;
		this.reason = reason;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getTokenId() {
		return tokenId;
	}
	public void setTokenId(Long tokenId) {
		this.tokenId = tokenId;
	}
	public LocalDateTime getCancelTime() {
		return cancelTime;
	}
	public void setCancelTime(LocalDateTime cancelTime) {
		this.cancelTime = cancelTime;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}

}