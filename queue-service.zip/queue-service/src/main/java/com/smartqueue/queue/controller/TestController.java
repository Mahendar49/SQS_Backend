package com.smartqueue.queue.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.smartqueue.queue.service.NotificationService;

@RestController
@RequestMapping("/test")
public class TestController {

    private final NotificationService notificationService;

    public TestController(NotificationService notificationService) {
        this.notificationService = notificationService;
    }

    @GetMapping("/ws")
    public String testWs() {

        notificationService.notifyUser(1L, "🔥 TEST MESSAGE FROM BACKEND",null,null);

        return "Sent!";
    }
}