package com.smartqueue.queue.client;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.smartqueue.queue.dto.CounterResponse;

@FeignClient(name = "business-service", url = "http://localhost:8082")
public interface BusinessClient {

    @GetMapping("/api/v1/business/{id}")
    Object getBusiness(@PathVariable Long id);

    @GetMapping("/api/v1/business/{id}/counters")
    List<CounterResponse> getCounters(@PathVariable Long id);
}