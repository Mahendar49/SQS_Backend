package com.smartqueue.queue.util;
public class PriorityUtil {

    public static int getPriorityWeight(String type) {
        return switch (type) {
            case "EMERGENCY" -> 1;
            case "PREMIUM" -> 2;
            default -> 3; // NORMAL
        };
    }
}