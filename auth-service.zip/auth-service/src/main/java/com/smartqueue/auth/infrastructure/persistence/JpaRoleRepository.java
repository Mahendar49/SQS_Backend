package com.smartqueue.auth.infrastructure.persistence;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;
import com.smartqueue.auth.domain.model.Role;

/**
 * Purpose:
 * JPA interface for Role persistence
 */
public interface JpaRoleRepository extends JpaRepository<Role, Long> {

    Optional<Role> findByName(String name);
}