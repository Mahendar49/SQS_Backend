package com.smartqueue.auth.application.usecase;
// application/usecase/VerifyOtpUseCase.java

import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.smartqueue.auth.common.exception.AuthException;
import com.smartqueue.auth.common.exception.OtpException;
import com.smartqueue.auth.domain.repository.OtpRepository;
import com.smartqueue.auth.domain.repository.UserRepository;

@Service
public class VerifyOtpUseCase {

    private final OtpRepository otpRepo;
    private final UserRepository userRepo;

    public VerifyOtpUseCase(OtpRepository otpRepo, UserRepository userRepo) {
        this.otpRepo = otpRepo;
        this.userRepo = userRepo;
    }

    private static final Logger log = LoggerFactory.getLogger(VerifyOtpUseCase.class);

    public void execute(Long userId, String otpInput) {

        log.info("OTP verification attempt for userId={}", userId);

        var otp = otpRepo.findTopByUserIdOrderByCreatedAtDesc(userId)
                .orElseThrow(() -> {
                    log.warn("OTP not found for userId={}", userId);
                    return new OtpException("OTP not found");
                });

        if (!otp.isValid(otpInput)) {
            log.warn("Invalid OTP attempt for userId={}", userId);
            throw new OtpException("Invalid or expired OTP");
        }

        otp.markUsed();

        var user = userRepo.findById(userId)
                .orElseThrow(() -> {
                    log.error("User not found during OTP verification: userId={}", userId);
                    return new AuthException("User not found");
                });

        user.verifyAccount();
        userRepo.save(user);

        log.info("User verified successfully: userId={}", userId);
    }
}