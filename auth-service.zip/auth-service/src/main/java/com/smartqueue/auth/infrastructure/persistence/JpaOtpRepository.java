package com.smartqueue.auth.infrastructure.persistence;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.smartqueue.auth.domain.model.OtpVerification;

@Repository
public interface JpaOtpRepository extends JpaRepository<OtpVerification, Long> {
    Optional<OtpVerification> findTopByUserIdOrderByCreatedAtDesc(Long userId);
}

