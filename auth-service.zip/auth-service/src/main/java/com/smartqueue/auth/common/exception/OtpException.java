package com.smartqueue.auth.common.exception;
public class OtpException extends BaseException {

    public OtpException(String message) {
        super("OTP_ERROR", message, null);
    }
}