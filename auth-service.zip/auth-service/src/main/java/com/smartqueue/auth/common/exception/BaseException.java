package com.smartqueue.auth.common.exception;
// common/exception/BaseException.java

public abstract class BaseException extends RuntimeException {

    private final String code;
    private final String details;

    public BaseException(String code, String message, String details) {
        super(message);
        this.code = code;
        this.details = details;
    }

    public String getCode() { return code; }

    public String getDetails() { return details; }
}