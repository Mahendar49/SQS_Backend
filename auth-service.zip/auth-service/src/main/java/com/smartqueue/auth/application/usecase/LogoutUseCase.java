package com.smartqueue.auth.application.usecase;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.smartqueue.auth.common.exception.AuthException;
import com.smartqueue.auth.domain.model.User;
import com.smartqueue.auth.domain.repository.RefreshTokenRepository;
import com.smartqueue.auth.domain.repository.UserRepository;

// application/usecase/LogoutUseCase.java
@Service
public class LogoutUseCase {

    private final RefreshTokenRepository refreshRepo;
    private final UserRepository userRepository;

    public LogoutUseCase(RefreshTokenRepository refreshRepo, UserRepository userRepository) {
        this.refreshRepo = refreshRepo;
        this.userRepository = userRepository;
    }

    private static final Logger log = LoggerFactory.getLogger(LogoutUseCase.class);

    public void execute(Long userId) {

        if (userId == null) {
            log.warn("Logout failed - missing userId");
            throw new AuthException("Invalid user context");
        }
        
        User user = userRepository.findById(userId).orElseThrow(
        		()-> new AuthException("User Not Found"));
        
        refreshRepo.revokeAllByUserId(user.getId());

        log.info("User logged out successfully: userId={}", userId);
    }
}