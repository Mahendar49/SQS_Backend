package com.smartqueue.auth.domain.model;

import jakarta.persistence.*;
import java.util.HashSet;
import java.util.Set;

/**
 * Purpose: Represents a role assigned to users.
 *
 * Responsibilities: - Group permissions - Assign to users
 *
 * Example: ADMIN → has multiple permissions
 */
@Entity
@Table(name = "roles")
public class Role {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	/**
	 * Unique role name (e.g., ADMIN, USER)
	 */
	@Column(unique = true, nullable = false)
	private String name;

	/**
	 * Description of role
	 */
	private String description;

	/**
	 * Permissions assigned to this role
	 */
	@ManyToMany(fetch = FetchType.LAZY)
	@JoinTable(name = "role_permissions", joinColumns = @JoinColumn(name = "role_id"), inverseJoinColumns = @JoinColumn(name = "permission_id"))
	private Set<Permission> permissions = new HashSet<>();

	protected Role() {
	}

	 public Role(String name, String description) {
		this.name = name;
		this.description = description;
	}

	public static Role create(String name, String description) {
		return new Role(name, description);
	}

	// ================= DOMAIN METHODS =================

	public void addPermission(Permission permission) {
		this.permissions.add(permission);
	}

	public void removePermission(Permission permission) {
		this.permissions.remove(permission);
	}

	public void clearPermissions() {
		this.permissions.clear();
	}

	// ================= GETTERS =================

	public Long getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public String getDescription() {
		return description;
	}

	public Set<Permission> getPermissions() {
		return Set.copyOf(permissions); // protect internal state
	}
}