package com.smartqueue.auth.infrastructure.messaging;

import org.springframework.stereotype.Component;

import com.smartqueue.auth.infrastructure.notification.EmailService;

/**
 * Publishes OTP event (email sending)
 */
@Component
public class AuthEventPublisherImpl implements AuthEventPublisher {

    private final EmailService emailService;

    public AuthEventPublisherImpl(EmailService emailService) {
        this.emailService = emailService;
    }

    @Override
    public void publishOtpRequested(Long userId, String email, String otp) {

        // ✅ SEND TO USER EMAIL
        emailService.sendOtpEmail(email, otp);
    }
}