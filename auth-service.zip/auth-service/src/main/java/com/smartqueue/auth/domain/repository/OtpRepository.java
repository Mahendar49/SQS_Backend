package com.smartqueue.auth.domain.repository;

import java.util.Optional;

import com.smartqueue.auth.domain.model.OtpVerification;

public interface OtpRepository {
    Optional<OtpVerification> findTopByUserIdOrderByCreatedAtDesc(Long userId);
    OtpVerification save(OtpVerification otp);
}