package com.smartqueue.auth.infrastructure.config;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.smartqueue.auth.domain.model.Role;
import com.smartqueue.auth.infrastructure.persistence.JpaRoleRepository;

/**
 * Purpose:
 * Initialize default roles at application startup
 *
 * Responsibilities:
 * - Ensure ADMIN role exists
 * - Ensure USER role exists
 */
@Configuration
public class DataInitializer {

    @Bean
    CommandLineRunner initRoles(JpaRoleRepository roleRepo) {
        return args -> {

            // ✅ Create ADMIN role if not exists
            if (roleRepo.findByName("ADMIN").isEmpty()) {
                roleRepo.save(new Role("ADMIN", "Admin"));
                System.out.println("ADMIN role created");
            }

            // ✅ Create USER role if not exists
            if (roleRepo.findByName("USER").isEmpty()) {
                roleRepo.save(new Role("USER", "User"));
                System.out.println("USER role created");
            }
        };
    }
}