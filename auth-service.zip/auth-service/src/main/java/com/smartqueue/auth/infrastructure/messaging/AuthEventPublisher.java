package com.smartqueue.auth.infrastructure.messaging;
// infrastructure/messaging/AuthEventPublisher.java
public interface AuthEventPublisher {
    void publishOtpRequested(Long userId, String email, String otp);
}

// simple impl (replace with Kafka/Rabbit later)
