package com.smartqueue.auth.api.request;

/**
 * Purpose:
 * Request payload for OTP verification
 */
public class VerifyOtpRequest {

    public Long userId;
    public String otp;
	public Long getUserId() {
		return userId;
	}
	public String getOtp() {
		return otp;
	}
    
    
}