package com.smartqueue.auth.infrastructure.persistence;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.smartqueue.auth.domain.model.RefreshToken;

// infrastructure/persistence/JpaRefreshTokenRepository.java
@Repository
public interface JpaRefreshTokenRepository extends JpaRepository<RefreshToken, Long> {
    Optional<RefreshToken> findByToken(String token);

    @Modifying
    @Transactional
    @Query("update RefreshToken t set t.revoked=true where t.userId=:userId")
    void revokeAllByUserId(@Param("userId") Long userId);
}

// Adapter
