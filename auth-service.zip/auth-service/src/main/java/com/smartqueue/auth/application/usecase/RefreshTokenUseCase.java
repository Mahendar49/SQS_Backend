package com.smartqueue.auth.application.usecase;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.smartqueue.auth.api.response.AuthResponse;
import com.smartqueue.auth.common.exception.AuthException;
import com.smartqueue.auth.common.exception.TokenException;
import com.smartqueue.auth.domain.model.RefreshToken;
import com.smartqueue.auth.domain.repository.RefreshTokenRepository;
import com.smartqueue.auth.domain.repository.UserRepository;
import com.smartqueue.auth.infrastructure.security.JwtService;

// application/usecase/RefreshTokenUseCase.java
@Service
public class RefreshTokenUseCase {

    private final RefreshTokenRepository refreshRepo;
    private final UserRepository userRepo;
    private final JwtService jwt;
    
    private static final Logger log = LoggerFactory.getLogger(RefreshTokenUseCase.class);


    public RefreshTokenUseCase(RefreshTokenRepository refreshRepo,
                              UserRepository userRepo,
                              JwtService jwt) {
        this.refreshRepo = refreshRepo;
        this.userRepo = userRepo;
        this.jwt = jwt;
    }

    public AuthResponse execute(String token) {

        log.info("Refresh token request received");

        var rt = refreshRepo.findByToken(token)
                .orElseThrow(() -> {
                    log.warn("Invalid refresh token");
                    return new TokenException("Invalid refresh token");
                });

        if (!rt.isValid()) {
            log.warn("Expired or revoked refresh token for userId={}", rt.getUserId());
            throw new TokenException("Expired or revoked refresh token");
        }

        var user = userRepo.findById(rt.getUserId())
                .orElseThrow(() -> {
                    log.error("User not found for refresh token userId={}", rt.getUserId());
                    return new AuthException("User not found");
                });

        log.info("Generating new tokens for userId={}", user.getId());


        // rotate old token
        rt.revoke();
        refreshRepo.save(rt);

        String newRt = java.util.UUID.randomUUID().toString();

        refreshRepo.save(
            RefreshToken.create(
                newRt,
                user.getId(),
                java.time.LocalDateTime.now().plusDays(7)
            )
        );

        var roles = user.getRoles().stream()
                .map(r -> r.getName())
                .collect(java.util.stream.Collectors.toSet());

        var perms = user.getRoles().stream()
                .flatMap(r -> r.getPermissions().stream())
                .map(p -> p.getName())
                .collect(java.util.stream.Collectors.toSet());

        String access = jwt.generateToken(
                user.getId(),
                user.getEmail(),
                roles,
                perms,
                user.isVerified()
        );

        return new AuthResponse(access, newRt, jwt.getExpirySeconds());
    }
}