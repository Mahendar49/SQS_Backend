package com.smartqueue.auth.domain.model;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;

/**
 * Purpose:
 * Represents authentication identity of a user.
 *
 * Responsibilities:
 * - Store credentials (email, password)
 * - Manage account state (lock, verification, deletion)
 * - Enforce domain rules (no invalid state transitions)
 * - Maintain RBAC relationships
 *
 * Important:
 * - No profile data stored here
 * - Used only for authentication & authorization
 */
@Entity
@Table(name = "users")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /**
     * Unique login identifier (stored in lowercase)
     */
    @Column(unique = true, nullable = false, updatable = false)
    private String email;

    /**
     * Hashed password (BCrypt)
     */
    @Column(nullable = false)
    private String password;

    /**
     * Account status
     */
    @Enumerated(EnumType.STRING)
    private AccountStatus status;

    /**
     * Email verification flag
     */
    private boolean isVerified;

    /**
     * Failed login attempts counter
     */
    private int failedAttempts;

    /**
     * Soft delete flag
     */
    private boolean isDeleted;

    /**
     * Deletion timestamp
     */
    private LocalDateTime deletedAt;

    /**
     * Account lock time
     */
    private LocalDateTime lockTime;

    /**
     * Last successful login timestamp
     */
    private LocalDateTime lastLoginAt;

    /**
     * Audit fields
     */
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    /**
     * RBAC mapping
     */
    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(
        name = "user_roles",
        joinColumns = @JoinColumn(name = "user_id"),
        inverseJoinColumns = @JoinColumn(name = "role_id")
    )
    private Set<Role> roles = new HashSet<>();

    // ================== CONSTRUCTORS ==================

    protected User() {}

    private User(String email, String password) {
        this.email = normalizeEmail(email);
        this.password = password;
        this.status = AccountStatus.PENDING_VERIFICATION;
        this.isVerified = false;
        this.failedAttempts = 0;
        this.isDeleted = false;
    }

    public static User create(String email, String encodedPassword) {
        return new User(email, encodedPassword);
    }

    // ================== DOMAIN RULES ==================

    private String normalizeEmail(String email) {
        return email.toLowerCase().trim();
    }

    private void ensureNotDeleted() {
        if (this.isDeleted) {
            throw new IllegalStateException("User account is deleted");
        }
    }

    // ================== DOMAIN METHODS ==================

    public void verifyAccount() {
        ensureNotDeleted();
        this.isVerified = true;
        this.status = AccountStatus.ACTIVE;
    }

    public void increaseFailedAttempts(int maxAttempts) {
        ensureNotDeleted();

        this.failedAttempts++;

        if (this.failedAttempts >= maxAttempts) {
            lockAccount();
        }
    }

    public void resetFailedAttempts() {
        this.failedAttempts = 0;
    }

    public void lockAccount() {
        this.status = AccountStatus.LOCKED;
        this.lockTime = LocalDateTime.now();
    }

    public void unlockAccount() {
        this.status = AccountStatus.ACTIVE;
        this.failedAttempts = 0;
        this.lockTime = null;
    }

    /**
     * Auto unlock check based on duration
     */
    public boolean isAccountLocked(long lockDurationMinutes) {
        if (this.status != AccountStatus.LOCKED) return false;

        if (lockTime == null) return false;

        return lockTime.plusMinutes(lockDurationMinutes)
                .isAfter(LocalDateTime.now());
    }

    public void markLoginSuccess() {
        ensureNotDeleted();

        this.lastLoginAt = LocalDateTime.now();
        resetFailedAttempts();
    }

    public void deleteAccount() {
        this.isDeleted = true;
        this.deletedAt = LocalDateTime.now();
        this.status = AccountStatus.DISABLED;
        this.roles.clear();
    }

    // ================== RBAC METHODS ==================

    public void addRole(Role role) {
        ensureNotDeleted();
        this.roles.add(role);
    }

    public void removeRole(Role role) {
        this.roles.remove(role);
    }

    public void clearRoles() {
        this.roles.clear();
    }

    // ================== HELPER METHODS ==================

    public boolean isActive() {
        return this.status == AccountStatus.ACTIVE && !this.isDeleted;
    }

    public boolean isEligibleForLogin(long lockDurationMinutes) {
        if (this.isDeleted) return false;

        if (this.status == AccountStatus.LOCKED) {
            return !isAccountLocked(lockDurationMinutes);
        }

        return this.status == AccountStatus.ACTIVE;
    }

    // ================== LIFECYCLE ==================

    @PrePersist
    protected void onCreate() {
        this.createdAt = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        this.updatedAt = LocalDateTime.now();
    }

    // ================== GETTERS ==================

    public Long getId() { return id; }

    public String getEmail() { return email; }

    public String getPassword() { return password; }

    public AccountStatus getStatus() { return status; }

    public boolean isVerified() { return isVerified; }

    public int getFailedAttempts() { return failedAttempts; }

    public LocalDateTime getLastLoginAt() { return lastLoginAt; }

    public boolean isDeleted() { return isDeleted; }

    /**
     * Return unmodifiable roles (protects internal state)
     */
    public Set<Role> getRoles() {
        return Collections.unmodifiableSet(roles);
    }
}