package com.smartqueue.auth.domain.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

/**
 * Stores refresh tokens for rotation + revocation.
 */
@Entity
@Table(name = "refresh_tokens")
public class RefreshToken {

    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private String token; // random UUID (NOT JWT)

    @Column(nullable = false)
    private Long userId;

    @Column(nullable = false)
    private LocalDateTime expiresAt;

    private boolean revoked;

    private LocalDateTime createdAt;

    protected RefreshToken() {}

    private RefreshToken(String token, Long userId, LocalDateTime expiresAt) {
        this.token = token;
        this.userId = userId;
        this.expiresAt = expiresAt;
        this.revoked = false;
        this.createdAt = LocalDateTime.now();
    }

    public static RefreshToken create(String token, Long userId, LocalDateTime expiresAt) {
        return new RefreshToken(token, userId, expiresAt);
    }

    public boolean isValid() {
        return !revoked && expiresAt.isAfter(LocalDateTime.now());
    }

    public void revoke() {
        this.revoked = true;
    }

    public String getToken() { return token; }
    public Long getUserId() { return userId; }
    public LocalDateTime getExpiresAt() { return expiresAt; }
}