package com.smartqueue.auth.domain.repository;

import java.util.Optional;
import com.smartqueue.auth.domain.model.Role;

public interface RoleRepository {
    Optional<Role> findByName(String name);
}