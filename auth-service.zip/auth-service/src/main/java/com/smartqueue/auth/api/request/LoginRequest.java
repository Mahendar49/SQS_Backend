package com.smartqueue.auth.api.request;
public class LoginRequest {
    public String email;
    public String password;
	public String getEmail() {
		return email;
	}
	public String getPassword() {
		return password;
	}
    
}

// api/request/RefreshRequest.java
