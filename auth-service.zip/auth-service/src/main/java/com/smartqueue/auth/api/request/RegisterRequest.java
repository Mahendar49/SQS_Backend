package com.smartqueue.auth.api.request;
// api/request/RegisterRequest.java
public class RegisterRequest {
    public String email;
    public String password;
}

// api/request/LoginRequest.java
