package com.smartqueue.auth.messaging.dto;
// messaging/dto/OtpEvent.java

public class OtpEvent {

    public Long userId;
    public String email;
    public String otp;
    public String type; // REGISTER / RESET_PASSWORD
}