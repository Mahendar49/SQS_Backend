package com.smartqueue.auth.common.exception;
public class InvalidCredentialsException extends BaseException {

    public InvalidCredentialsException() {
        super("INVALID_CREDENTIALS", "Invalid email or password", null);
    }
}