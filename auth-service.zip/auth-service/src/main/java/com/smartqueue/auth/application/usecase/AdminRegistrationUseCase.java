package com.smartqueue.auth.application.usecase;

import org.springframework.stereotype.Service;

@Service
public class AdminRegistrationUseCase {

    private final RegisterUserUseCase registerUC;

    public AdminRegistrationUseCase(RegisterUserUseCase registerUC) {
        this.registerUC = registerUC;
    }

    public void execute(String email, String password) {
        registerUC.execute(email, password, "ADMIN");
    }
}