package com.smartqueue.auth.common.api;
// common/api/ErrorResponse.java

import java.time.LocalDateTime;

public class ApiError {

    private String code;        // BUSINESS_ERROR_CODE
    private String message;     // user-friendly
    private String details;     // internal debug
    private LocalDateTime timestamp;

    public ApiError(String code, String message, String details) {
        this.code = code;
        this.message = message;
        this.details = details;
        this.timestamp = LocalDateTime.now();
    }

	public String getCode() {
		return code;
	}

	public String getMessage() {
		return message;
	}

	public String getDetails() {
		return details;
	}

	public LocalDateTime getTimestamp() {
		return timestamp;
	}

    // getters
    
}