package com.smartqueue.auth.api.response;
public class AuthResponse {
    public String accessToken;
    public String refreshToken;
    public long expiresIn;

    public AuthResponse(String at, String rt, long exp) {
        this.accessToken = at; this.refreshToken = rt; this.expiresIn = exp;
    }
}