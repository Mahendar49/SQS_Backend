package com.smartqueue.auth.api.request;
public class RefreshRequest {
    public String refreshToken;
}

