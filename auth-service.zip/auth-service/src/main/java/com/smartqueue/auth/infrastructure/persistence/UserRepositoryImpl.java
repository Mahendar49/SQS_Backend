package com.smartqueue.auth.infrastructure.persistence;

import java.util.Optional;

import org.springframework.stereotype.Component;

import com.smartqueue.auth.domain.model.User;
import com.smartqueue.auth.domain.repository.UserRepository;

@Component
public class UserRepositoryImpl implements UserRepository {
	private final JpaUserRepository jpa;

	public UserRepositoryImpl(JpaUserRepository jpa) {
		this.jpa = jpa;
	}
	@Override
	public Optional<User> findByEmail(String email) {
		return jpa.findByEmail(email.toLowerCase().trim());
	}

	 @Override
	    public Optional<User> findById(Long id) {
	        return jpa.findById(id);
	    }
	 @Override
	public User save(User u) {
		return jpa.save(u);
	}
}