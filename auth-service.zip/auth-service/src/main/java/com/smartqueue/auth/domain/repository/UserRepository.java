package com.smartqueue.auth.domain.repository;

import java.util.Optional;

import com.smartqueue.auth.domain.model.User;

public interface UserRepository {
	Optional<User> findByEmail(String email);
	Optional<User> findById(Long id);
	User save(User user);
}

