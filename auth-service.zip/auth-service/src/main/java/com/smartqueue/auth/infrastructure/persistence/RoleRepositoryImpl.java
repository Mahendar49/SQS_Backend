package com.smartqueue.auth.infrastructure.persistence;

import java.util.Optional;

import org.springframework.stereotype.Component;

import com.smartqueue.auth.domain.model.Role;
import com.smartqueue.auth.domain.repository.RoleRepository;

/**
 * Purpose:
 * Adapter to connect domain layer with JPA layer
 */
@Component
public class RoleRepositoryImpl implements RoleRepository {

    private final JpaRoleRepository jpa;

    public RoleRepositoryImpl(JpaRoleRepository jpa) {
        this.jpa = jpa;
    }

    @Override
    public Optional<Role> findByName(String name) {
        return jpa.findByName(name);
    }
}