package com.smartqueue.auth.common.exception;
// common/exception/GlobalExceptionHandler.java

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.smartqueue.auth.common.api.ApiError;
import com.smartqueue.auth.common.api.ApiResponse;

@RestControllerAdvice
public class GlobalExceptionHandler {
	
	 private static final Logger log = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    /**
     * Handles all custom business exceptions
     */
    @ExceptionHandler(BaseException.class)
    public ResponseEntity<ApiResponse<?>> handleBaseException(BaseException ex) {
    	
    	log.warn("Business exception occurred: code={}, message={}",
                ex.getCode(), ex.getMessage());
        
    	ApiError error = new ApiError(
                ex.getCode(),
                ex.getMessage(),
                ex.getDetails()
        );

        return ResponseEntity
                .badRequest()
                .body(ApiResponse.failure(error));
    }

    /**
     * Handles unexpected exceptions
     */
    @ExceptionHandler(Exception.class)
    public ResponseEntity<ApiResponse<?>> handleGeneric(Exception ex) {

    	log.error("Unexpected system error", ex);
    	
        ApiError error = new ApiError(
                "INTERNAL_SERVER_ERROR",
                "Something went wrong",
                ex.getMessage()
        );

        return ResponseEntity
                .status(500)
                .body(ApiResponse.failure(error));
    }
}