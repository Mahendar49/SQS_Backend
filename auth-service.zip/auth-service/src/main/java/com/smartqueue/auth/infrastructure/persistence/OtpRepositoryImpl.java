package com.smartqueue.auth.infrastructure.persistence;

import java.util.Optional;

import org.springframework.stereotype.Component;

import com.smartqueue.auth.domain.model.OtpVerification;
import com.smartqueue.auth.domain.repository.OtpRepository;

@Component
public class OtpRepositoryImpl implements OtpRepository {

    private final JpaOtpRepository jpa;

    public OtpRepositoryImpl(JpaOtpRepository jpa) {
        this.jpa = jpa;
    }

    public Optional<OtpVerification> findTopByUserIdOrderByCreatedAtDesc(Long userId) {
        return jpa.findTopByUserIdOrderByCreatedAtDesc(userId);
    }

    public OtpVerification save(OtpVerification otp) {
        return jpa.save(otp);
    }
}