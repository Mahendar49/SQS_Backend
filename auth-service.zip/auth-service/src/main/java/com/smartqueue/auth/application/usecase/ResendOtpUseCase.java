package com.smartqueue.auth.application.usecase;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.smartqueue.auth.common.exception.AuthException;
import com.smartqueue.auth.domain.model.OtpVerification;
import com.smartqueue.auth.domain.repository.OtpRepository;
import com.smartqueue.auth.domain.repository.UserRepository;
import com.smartqueue.auth.infrastructure.messaging.AuthEventPublisher;

/**
 * Purpose:
 * Resend OTP if expired or not received
 */
@Service
public class ResendOtpUseCase {

    private final UserRepository userRepo;
    private final OtpRepository otpRepo;
    private final AuthEventPublisher publisher;

    private static final Logger log = LoggerFactory.getLogger(ResendOtpUseCase.class);

    public ResendOtpUseCase(UserRepository userRepo,
                            OtpRepository otpRepo,
                            AuthEventPublisher publisher) {
        this.userRepo = userRepo;
        this.otpRepo = otpRepo;
        this.publisher = publisher;
    }

    public void execute(Long userId) {

        var user = userRepo.findById(userId)
                .orElseThrow(() -> new AuthException("User not found"));

        // 🔥 Generate new OTP
        String otp = generateOtp();

        otpRepo.save(OtpVerification.create(user.getId(), otp, 5));

        log.info("Resent OTP for userId={}", userId);

        publisher.publishOtpRequested(user.getId(), user.getEmail(), otp);
    }

    private String generateOtp() {
        int n = new java.util.Random().nextInt(900000) + 100000;
        return String.valueOf(n);
    }
}