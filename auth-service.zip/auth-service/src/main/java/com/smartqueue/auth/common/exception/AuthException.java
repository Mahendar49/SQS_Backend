package com.smartqueue.auth.common.exception;
// common/exception/AuthException.java

public class AuthException extends BaseException {

    public AuthException(String message) {
        super("AUTH_ERROR", message, null);
    }
}