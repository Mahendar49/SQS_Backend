package com.smartqueue.auth.common.exception;
public class AccountLockedException extends BaseException {

    public AccountLockedException() {
        super("ACCOUNT_LOCKED", "Account is temporarily locked", null);
    }
}