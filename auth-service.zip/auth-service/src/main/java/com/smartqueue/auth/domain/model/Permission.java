package com.smartqueue.auth.domain.model;

import jakarta.persistence.*;

/**
 * Purpose: Represents a fine-grained action that can be performed.
 *
 * Examples: - CREATE_QUEUE - CANCEL_QUEUE - VIEW_ANALYTICS - MANAGE_COUNTER
 */
@Entity
@Table(name = "permissions")
public class Permission {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	/**
	 * Unique permission name
	 */
	@Column(unique = true, nullable = false)
	private String name;

	/**
	 * Description of permission
	 */
	private String description;

	protected Permission() {
	}

	private Permission(String name, String description) {
		this.name = name;
		this.description = description;
	}

	public static Permission create(String name, String description) {
		return new Permission(name, description);
	}

	// ================= GETTERS =================

	public Long getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public String getDescription() {
		return description;
	}
}