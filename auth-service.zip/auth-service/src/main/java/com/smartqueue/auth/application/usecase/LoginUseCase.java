package com.smartqueue.auth.application.usecase;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.smartqueue.auth.api.response.AuthResponse;
import com.smartqueue.auth.common.exception.AccountLockedException;
import com.smartqueue.auth.common.exception.InvalidCredentialsException;
import com.smartqueue.auth.domain.model.RefreshToken;
import com.smartqueue.auth.domain.repository.RefreshTokenRepository;
import com.smartqueue.auth.domain.repository.UserRepository;
import com.smartqueue.auth.infrastructure.security.JwtService;

// application/usecase/LoginUseCase.java
@Service
public class LoginUseCase {

    private final UserRepository userRepo;
    private final PasswordEncoder encoder;
    private final JwtService jwt;
    private final RefreshTokenRepository refreshRepo;

    @Value("${security.lock.minutes:15}")
    private long lockMinutes;

    @Value("${security.refresh.days:7}")
    private long refreshDays;

    public LoginUseCase(UserRepository userRepo,
                        PasswordEncoder encoder,
                        JwtService jwt,
                        RefreshTokenRepository refreshRepo) {
        this.userRepo = userRepo;
        this.encoder = encoder;
        this.jwt = jwt;
        this.refreshRepo = refreshRepo;
    }

    private static final Logger log = LoggerFactory.getLogger(LoginUseCase.class);
    @Transactional
    public AuthResponse execute(String email, String password) {

        log.info("Login attempt for email={}", email);

        var user = userRepo.findByEmail(email)
                .orElseThrow(() -> {
                    log.warn("Login failed - user not found: {}", email);
                    return new InvalidCredentialsException();
                });

        if (user.getStatus().name().equals("LOCKED") &&
            !user.isAccountLocked(lockMinutes)) {

            log.info("Auto unlocking account for userId={}", user.getId());
            user.unlockAccount();
        }

        if (!user.isEligibleForLogin(lockMinutes)) {
            log.warn("Login blocked - account locked: userId={}", user.getId());
            throw new AccountLockedException();
        }

        if (!encoder.matches(password, user.getPassword())) {
            log.warn("Login failed - invalid password for email={}", email);

            user.increaseFailedAttempts(5);
            userRepo.save(user);

            throw new InvalidCredentialsException();
        }

        user.markLoginSuccess();
        userRepo.save(user);

        log.info("Login success for userId={}", user.getId());

        // extract roles/permissions
        var roles = user.getRoles().stream().map(r -> r.getName()).collect(java.util.stream.Collectors.toSet());
        var perms = user.getRoles().stream()
                .flatMap(r -> r.getPermissions().stream())
                .map(p -> p.getName())
                .collect(java.util.stream.Collectors.toSet());

        String access = jwt.generateToken(user.getId(), user.getEmail(), roles, perms, user.isVerified());

        // refresh token (rotate)
        refreshRepo.revokeAllByUserId(user.getId());
        String rt = java.util.UUID.randomUUID().toString();
        var entity = RefreshToken.create(
                rt,
                user.getId(),
                java.time.LocalDateTime.now().plusDays(refreshDays)
        );
        refreshRepo.save(entity);

        return new AuthResponse(access, rt, jwt.getExpirySeconds());
    }
}