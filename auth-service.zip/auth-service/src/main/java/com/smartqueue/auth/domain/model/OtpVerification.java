package com.smartqueue.auth.domain.model;
// domain/model/OtpVerification.java

import java.time.LocalDateTime;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "otp_verifications")
public class OtpVerification {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long userId;

    private String otp;

    private LocalDateTime expiresAt;

    private boolean used;

    private LocalDateTime createdAt;

    protected OtpVerification() {}

    private OtpVerification(Long userId, String otp, LocalDateTime expiresAt) {
        this.userId = userId;
        this.otp = otp;
        this.expiresAt = expiresAt;
        this.used = false;
        this.createdAt = LocalDateTime.now();
    }

    public static OtpVerification create(Long userId, String otp, int minutes) {
        return new OtpVerification(
                userId,
                otp,
                LocalDateTime.now().plusMinutes(minutes)
        );
    }

    public boolean isValid(String inputOtp) {
        return !used &&
               this.otp.equals(inputOtp) &&
               this.expiresAt.isAfter(LocalDateTime.now());
    }

    public void markUsed() {
        this.used = true;
    }

    public Long getUserId() { return userId; }
}