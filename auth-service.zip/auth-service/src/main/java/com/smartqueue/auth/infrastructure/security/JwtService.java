package com.smartqueue.auth.infrastructure.security;

import java.util.Date;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;

// infrastructure/security/JwtService.java
@Component
public class JwtService {

    @Value("${security.jwt.secret}")
    private String secret;

    @Value("${security.jwt.exp-minutes:15}")
    private long expMinutes;

    public String generateToken(Long userId, String email, 
                                java.util.Set<String> roles,
                                java.util.Set<String> permissions,
                                boolean isVerified) {

        var now = java.time.Instant.now();
        var exp = now.plus(java.time.Duration.ofMinutes(expMinutes));

        return Jwts.builder()
            .setSubject(String.valueOf(userId))
            .claim("email", email)
            .claim("roles", roles)
            .claim("permissions", permissions)
            .claim("isVerified", isVerified)
            .setIssuedAt(Date.from(now))
            .setExpiration(Date.from(exp))
            .signWith(Keys.hmacShaKeyFor(secret.getBytes()))
            .compact();
    }

    public long getExpirySeconds() { return expMinutes * 60; }
}