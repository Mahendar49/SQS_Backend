package com.smartqueue.auth.api.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.smartqueue.auth.api.request.*;
import com.smartqueue.auth.api.response.AuthResponse;
import com.smartqueue.auth.application.usecase.*;
import com.smartqueue.auth.common.api.ApiResponse;

/**
 * Purpose:
 * Handles authentication-related endpoints
 *
 * Responsibilities:
 * - Delegate requests to use cases
 * - Wrap responses in ApiResponse
 */
@RestController
@RequestMapping("/api/v1/auth")
public class AuthController {

    private final RegisterUserUseCase registerUC;
    private final LoginUseCase loginUC;
    private final RefreshTokenUseCase refreshUC;
    private final LogoutUseCase logoutUC;
    private final VerifyOtpUseCase verifyOtpUC;
    private final UserRegistrationUseCase userRegisterUC;
    private final AdminRegistrationUseCase adminRegisterUC;
    private final ResendOtpUseCase resendOtpUC;

    public AuthController(RegisterUserUseCase r,
                          LoginUseCase l,
                          RefreshTokenUseCase ref,
                          LogoutUseCase lo,
                          VerifyOtpUseCase ver,
                          UserRegistrationUseCase userRegisterUC,
                          AdminRegistrationUseCase adminRegisterUC,
                          ResendOtpUseCase resendOtpUC) {
        this.registerUC = r;
        this.loginUC = l;
        this.refreshUC = ref;
        this.logoutUC = lo;
        this.verifyOtpUC = ver;
        this.userRegisterUC = userRegisterUC;
        this.adminRegisterUC = adminRegisterUC;
        this.resendOtpUC = resendOtpUC;
    }

    /**
     * Register new user
     */
    @PostMapping("/register/user")
    public ResponseEntity<ApiResponse<String>> registerUser(@RequestBody RegisterRequest req) {

        userRegisterUC.execute(req.email, req.password);

        return ResponseEntity.ok(
                ApiResponse.success("User registered successfully and OTP sent to the email !")
        );
    }
    
    @PostMapping("/register/admin")
    public ResponseEntity<ApiResponse<String>> registerAdmin(@RequestBody RegisterRequest req) {

        adminRegisterUC.execute(req.email, req.password);

        return ResponseEntity.ok(
                ApiResponse.success("Admin registered successfully and OTP sent to the email !")
        );
    }
    
    
    @PostMapping("/verify")
    public ResponseEntity<ApiResponse<String>> verifyOtp(@RequestBody VerifyOtpRequest req) {

        verifyOtpUC.execute(req.userId, req.otp);

        return ResponseEntity.ok(
                ApiResponse.success("Account verified successfully")
        );
    }

    /**
     * Login user
     */
    @PostMapping("/login")
    public ResponseEntity<ApiResponse<AuthResponse>> login(@RequestBody LoginRequest req) {

        AuthResponse response = loginUC.execute(req.email, req.password);

        return ResponseEntity.ok(ApiResponse.success(response));
    }

    /**
     * Refresh token
     */
    @PostMapping("/refresh")
    public ResponseEntity<ApiResponse<AuthResponse>> refresh(@RequestBody RefreshRequest req) {

        AuthResponse response = refreshUC.execute(req.refreshToken);

        return ResponseEntity.ok(ApiResponse.success(response));
    }

    /**
     * Logout user
     */
    @PostMapping("/logout")
    public ResponseEntity<ApiResponse<String>> logout(@RequestHeader("X-User-Id") Long userId) {

        logoutUC.execute(userId);

        return ResponseEntity.ok(
                ApiResponse.success("Logged out successfully")
        );
    }
    
	/**
	 *  Resend otp
	 */
    @PostMapping("/resend-otp")
    public ResponseEntity<ApiResponse<String>> resendOtp(@RequestParam Long userId) {

        resendOtpUC.execute(userId);

        return ResponseEntity.ok(
                ApiResponse.success("OTP resent successfully")
        );
    }
    
}