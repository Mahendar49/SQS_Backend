package com.smartqueue.auth.infrastructure.notification;

import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

/**
 * Sends OTP to actual user email
 */
@Service
public class EmailService {

    private final JavaMailSender mailSender;

    public EmailService(JavaMailSender mailSender) {
        this.mailSender = mailSender;
    }

    public void sendOtpEmail(String toEmail, String otp) {

        SimpleMailMessage message = new SimpleMailMessage();

        // ✅ IMPORTANT: send to USER email (not config email)
        message.setTo(toEmail);

        message.setSubject("OTP Verification - Smart Queue");

        message.setText(
                "Hello,\n\n" +
                "Your OTP is: " + otp + "\n\n" +
                "Valid for 5 minutes.\n\n" +
                "Regards,\nSmart Queue System"
        );

        mailSender.send(message);
    }
}