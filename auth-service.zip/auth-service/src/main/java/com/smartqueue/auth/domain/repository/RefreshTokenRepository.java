package com.smartqueue.auth.domain.repository;

import com.smartqueue.auth.domain.model.RefreshToken;

public interface RefreshTokenRepository {
	java.util.Optional<RefreshToken> findByToken(String token);

	RefreshToken save(RefreshToken t);

	void revokeAllByUserId(Long userId);
}