package com.smartqueue.auth.common.exception;
public class TokenException extends BaseException {

    public TokenException(String message) {
        super("TOKEN_ERROR", message, null);
    }
}