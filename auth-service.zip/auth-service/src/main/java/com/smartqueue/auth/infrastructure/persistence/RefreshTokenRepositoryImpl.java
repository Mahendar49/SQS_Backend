package com.smartqueue.auth.infrastructure.persistence;

import java.util.Optional;

import org.springframework.stereotype.Component;

import com.smartqueue.auth.domain.model.RefreshToken;
import com.smartqueue.auth.domain.repository.RefreshTokenRepository;

@Component
public class RefreshTokenRepositoryImpl implements RefreshTokenRepository {
    private final JpaRefreshTokenRepository jpa;
    public RefreshTokenRepositoryImpl(JpaRefreshTokenRepository jpa) { this.jpa = jpa; }

    public Optional<RefreshToken> findByToken(String token) { return jpa.findByToken(token); }
    public RefreshToken save(RefreshToken t) { return jpa.save(t); }
    public void revokeAllByUserId(Long userId) { jpa.revokeAllByUserId(userId); }
}