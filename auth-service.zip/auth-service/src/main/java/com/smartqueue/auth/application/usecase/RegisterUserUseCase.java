package com.smartqueue.auth.application.usecase;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.smartqueue.auth.common.exception.AuthException;
import com.smartqueue.auth.domain.model.OtpVerification;
import com.smartqueue.auth.domain.model.User;
import com.smartqueue.auth.domain.repository.OtpRepository;
import com.smartqueue.auth.domain.repository.RoleRepository;
import com.smartqueue.auth.domain.repository.UserRepository;
import com.smartqueue.auth.infrastructure.messaging.AuthEventPublisher;

@Service
public class RegisterUserUseCase {

    private final UserRepository userRepo;
    private final PasswordEncoder encoder;
    private final AuthEventPublisher publisher;
    private final OtpRepository otpRepo;
    private final RoleRepository roleRepo;

    private static final Logger log = LoggerFactory.getLogger(RegisterUserUseCase.class);

    public RegisterUserUseCase(UserRepository userRepo,
                               PasswordEncoder encoder,
                               AuthEventPublisher publisher,
                               OtpRepository otpRepo,
                               RoleRepository roleRepo) {
        this.userRepo = userRepo;
        this.encoder = encoder;
        this.publisher = publisher;
        this.otpRepo = otpRepo;
        this.roleRepo = roleRepo;
    }

    /**
     * Core registration logic with dynamic role assignment
     */
    public void execute(String email, String rawPassword, String roleName) {

        log.info("Register request received for email={} role={}", email, roleName);

        userRepo.findByEmail(email).ifPresent(u -> {
            log.warn("Registration failed - email already exists: {}", email);
            throw new AuthException("Email already registered");
        });

        var user = User.create(email, encoder.encode(rawPassword));

        // 🔥 Assign Role
        var role = roleRepo.findByName(roleName)
                .orElseThrow(() -> new AuthException("Role not found: " + roleName));

        user.addRole(role);

        userRepo.save(user);

        log.info("User created with userId={} role={}", user.getId(), roleName);

        String otp = generateOtp();

        otpRepo.save(OtpVerification.create(user.getId(), otp, 5));

        publisher.publishOtpRequested(user.getId(), user.getEmail(), otp);
    }

    private String generateOtp() {
        int n = new java.util.Random().nextInt(900000) + 100000;
        return String.valueOf(n);
    }
}