package com.smartqueue.business.dto;
public class CounterRequest {
    private String name;
    private Integer avgServiceTime;
    public CounterRequest() {
		// TODO Auto-generated constructor stub
	}
	public CounterRequest(String name, Integer avgServiceTime) {
		super();
		this.name = name;
		this.avgServiceTime = avgServiceTime;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getAvgServiceTime() {
		return avgServiceTime;
	}
	public void setAvgServiceTime(Integer avgServiceTime) {
		this.avgServiceTime = avgServiceTime;
	}
    
}