package com.smartqueue.business.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.smartqueue.business.entity.Queue;

public interface QueueRepository extends JpaRepository<Queue, Long> {}