package com.smartqueue.business.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.smartqueue.business.entity.Business;

public interface BusinessRepository extends JpaRepository<Business, Long> {}