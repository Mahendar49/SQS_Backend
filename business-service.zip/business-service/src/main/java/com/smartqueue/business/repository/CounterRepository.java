package com.smartqueue.business.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.smartqueue.business.entity.Counter;

public interface CounterRepository extends JpaRepository<Counter, Long> {

    List<Counter> findByBusinessId(Long businessId);
}